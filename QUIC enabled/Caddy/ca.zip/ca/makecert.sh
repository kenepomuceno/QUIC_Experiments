#!/bin/sh

path="$HOME/ca"

if [ -z $1 ]; then
	echo -e "Informar dominio"
	exit
fi

#create CSR
openssl req -config ${path}/intermediate/openssl.cnf -key ${path}/intermediate/private/master_client.key.pem -new -sha256 -out ${path}/intermediate/csr/$1.csr.pem -subj '/C=BR/ST=Pernambuco/L=Recife/O=GPRT Inc./OU=HIPSTER Security Labs/CN='$1'/emailAddress=security@gprt.ufpe.br/subjectAltName=DNS.1='$1

#sign the CSR, create the CRT, the cert itself
openssl ca -batch -config ${path}/intermediate/openssl.cnf -extensions server_cert -days 375 -notext -md sha256 -in ${path}/intermediate/csr/$1.csr.pem -out ${path}/intermediate/certs/$1.cert.pem
