#!/bin/bash
IFS='
'
path="$HOME/ca"
cert="${path}/intermediate/certs/"
key="${path}/intermediate/private/master_client.key.pem"

###change mm-webreplay apaches ports 443 -> 444 and 80 -> 81

for conf in /tmp/replayshell_apache_config*; do
        ip=`sudo grep "^Listen" $conf | cut -d" " -f2 | cut -d: -f1`;
        port=`sudo grep "^Listen" $conf | cut -d" " -f2 | cut -d: -f2`;
        #domain=`nslookup $ip | grep arpa | cut -d" " -f3 | sed s/\.$//g`
        if [ $port -eq "443" ]; then
                #change conf port from 443 to 444
                #sudo sed -i s/'SSLEngine on'/'SSLEngine off'/g $conf
                sudo sed -i s/":$port$"/':444'/g $conf
                #restart apache with new settings
                sudo /usr/sbin/apache2 -f $conf -k restart
        fi
done

for conf in /tmp/replayshell_apache_config*; do
        ip=`sudo grep "^Listen" $conf | cut -d" " -f2 | cut -d: -f1`;
        port=`sudo grep "^Listen" $conf | cut -d" " -f2 | cut -d: -f2`;
        #domain=`nslookup $ip | grep arpa | cut -d" " -f3 | sed s/\.$//g`

        if [ $port -eq "80" ]; then
                #change conf port from 80 to 81
                sudo sed -i s/":$port$"/':81'/g $conf
                #restart apache with new settings
                sudo /usr/sbin/apache2 -f $conf -k restart
                #start http redirector http -> https
                #sudo ./redirect $ip $port '/triggered' &

        fi
done

###
# Run one caddy server for each mm-webreplay IP

sudo ulimit -n 8192

for ip in `sudo cat /tmp/replayshell_hosts.* | sort | cut -d" " -f1 | uniq`; do
	#echo $ip;
	tmp=`mktemp`
	for domain in `sudo grep $ip /tmp/replayshell_hosts.* | cut -d" " -f2 | sort | uniq`; do
		#redirect requests from http to https and inject tag
		echo -e "${domain}:80 {" >> $tmp
		echo -e "\tredir https://${domain}/triggered{uri}">> $tmp
		echo -e "\tbind $ip" >> $tmp
		echo -e "}" >> $tmp

		echo -e "${domain}:443 {" >> $tmp
		echo -e "\tproxy / https://${domain}:444 http://${domain}:81 {" >> $tmp
		echo -e "\t\tinsecure_skip_verify" >> $tmp 
		echo -e "\t\texcept /triggered" >> $tmp
		echo -e "\t\theader_downstream -Content-Security-Policy ''" >> $tmp
		echo -e "\t}" >> $tmp
		echo -e "\tproxy /triggered http://${domain}:81 {" >> $tmp
		echo -e "\t\twithout /triggered" >> $tmp
		echo -e "\t\theader_downstream -Content-Security-Policy ''" >> $tmp
		echo -e "\t}" >> $tmp
		echo -e "\tbind $ip" >> $tmp

		if [ ! -f ${cert}${domain}.cert.pem ]; then
			$path/makecert.sh ${domain} > /dev/null
		fi
		echo -e "\ttls ${cert}${domain}.cert.pem $key" >> $tmp

		echo -e "}" >> $tmp
	done
    cat ${tmp}
	sudo $HOME/caddy -http2=false -quic -port 443 -conf $tmp &
	sleep 1
	rm -f $tmp
done

if [ ! -z $1 ]; then
    #execute all args as command
    $@

    #cleanup
    ps aux | grep caddy | grep -v grep | awk '{print $2}' | xargs sudo kill -9
fi

