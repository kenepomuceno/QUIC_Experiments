#!/bin/sh
if [ -d x ]; then
	rm -Rf x;
fi
/opt/google/chrome/chrome --remote-debugging-port=9222 --enable-benchmarking --enable-net-benchmarking --no-first-run --disable-background-networking --user-agent='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36' --user-data-dir=x --enable-quic --allow-running-insecure-content
