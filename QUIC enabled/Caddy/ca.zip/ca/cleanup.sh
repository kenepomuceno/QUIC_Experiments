#!/bin/bash
ps aux | grep "apache\|dnsmasq\|httpd\|caddy" | grep -v grep | awk '{print $2}' | xargs sudo kill -9
sudo rm -f /tmp/replayshell_*
if [ -d x ]; then
    rm -Rf x
fi
